/*
 * ModelLoadException.java
 *
 * Created on March 13, 2008, 9:48 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.joglutils.model;

/**
 *
 * @author RodgersGB
 */
public class ModelLoadException extends Exception {
    
    /** Creates a new instance of ModelLoadException */
    public ModelLoadException() {
    }
    
    public ModelLoadException(String message) {
        super(message);
    }
}
